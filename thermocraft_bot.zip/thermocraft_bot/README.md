# ThermoCrafts Telegram Bot

## 3 qadam bilan ishga tushirish

### 1. Bot token olish
1. Telegramda @BotFather ga yozing
2. /newbot buyrug'ini yuboring
3. Bot nomi: ThermoCrafts
4. Username: thermocraft_uz_bot (yoki boshqa)
5. Token olasiz (ko'rinishi: 7123456789:AAF...)

### 2. Anthropic API key olish
1. https://console.anthropic.com ga kiring
2. API Keys → Create Key
3. Kalitni nusxa oling (sk-ant-...)

### 3. Railway.app da joylashtirish
1. https://railway.app ga kiring → Sign up (GitHub bilan)
2. New Project → Deploy from GitHub repo
   (GitHub da repo ochib, bu fayllarni yuklang)
   
   YOKI: New Project → Deploy → Empty Project
   Keyin: Files bo'limida bot.py va requirements.txt yuklang

3. Variables bo'limiga qo'shing:
   BOT_TOKEN = 7123456789:AAF... (sizning tokeningiz)
   ANTHROPIC_KEY = sk-ant-... (sizning kalitingiz)
   OWNER_ID = 123456789 (sizning Telegram ID'ingiz)

4. Telegram ID ni bilish uchun: @userinfobot ga /start yuboring

5. Deploy → bot ishlaydi!

## Bot nima qiladi

**Buyruqlar:**
/astatka  — barcha tovarlar
/bugun    — bugungi savdo
/oy       — oylik hisobot
/yordam   — yo'riqnoma

**Erkin yozish:**
"TTS 10 Pro sotdim 260 ga"
"3 ta CNC3018 keldi"
"Lazer astatka qanday"
"Bugungi savdo ko'rsat"
"TTS 20 narxi qancha"
